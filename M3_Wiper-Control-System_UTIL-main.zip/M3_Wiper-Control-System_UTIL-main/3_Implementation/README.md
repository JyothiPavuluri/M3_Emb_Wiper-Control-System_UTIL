# Here are the below steps to run the code
 * For Building the code
    * Type ***make Build*** in terminal
 * For Running the Building tests
    * Type ***make run_test*** in terminal
 * For static analysis
    * Type ***make static_analysis*** in terminal
 * For cleaning
    * Type  ***make clean*** in terminal
