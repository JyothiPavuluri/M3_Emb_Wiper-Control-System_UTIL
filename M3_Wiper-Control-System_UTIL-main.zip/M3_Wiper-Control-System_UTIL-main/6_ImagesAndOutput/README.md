# Output
![WhatsApp Image 2022-05-14 at 3 36 44 PM](https://user-images.githubusercontent.com/101269692/168421572-1c3bbdc9-6074-4aae-a6e3-e0e844eafed9.jpeg)

The Red LED is ON, ifthe user button is pressed and held for 2 secs. 


![WhatsApp Image 2022-05-14 at 3 36 43 PM](https://user-images.githubusercontent.com/101269692/168421584-94e3973e-4fc3-4e1a-8797-54c2c143b8f7.jpeg)

On press of the user input, Blue, Green and Orange LEDs come ON one at a time with the set frequency.
